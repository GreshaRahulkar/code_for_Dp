import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';
import '../presentation/last_onboarding_page_screen/last_onboarding_page_screen.dart';
import '../presentation/onboarding_fone_screen/onboarding_fone_screen.dart';
import '../presentation/onboarding_fthree_screen/onboarding_fthree_screen.dart';
import '../presentation/onboarding_ftwo_screen/onboarding_ftwo_screen.dart';
import '../presentation/welcome_screen/welcome_screen.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String welcomeScreen = '/welcome_screen';

  static const String onboardingFoneScreen = '/onboarding_fone_screen';

  static const String onboardingFtwoScreen = '/onboarding_ftwo_screen';

  static const String onboardingFthreeScreen = '/onboarding_fthree_screen';

  static const String lastOnboardingPageScreen = '/last_onboarding_page_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    welcomeScreen: (context) => WelcomeScreen(),
    onboardingFoneScreen: (context) => OnboardingFoneScreen(),
    onboardingFtwoScreen: (context) => OnboardingFtwoScreen(),
    onboardingFthreeScreen: (context) => OnboardingFthreeScreen(),
    lastOnboardingPageScreen: (context) => LastOnboardingPageScreen(),
    appNavigationScreen: (context) => AppNavigationScreen(),
    initialRoute: (context) => WelcomeScreen()
  };
}
