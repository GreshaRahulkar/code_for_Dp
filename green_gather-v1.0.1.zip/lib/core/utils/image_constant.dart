// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// onboarding fOne images
  static String imgPolygon1 = '$imagePath/img_polygon_1.svg';

  static String imgVector1 = '$imagePath/img_vector_1.png';

  static String imgStar1 = '$imagePath/img_star_1.svg';

  static String imgEllipse2 = '$imagePath/img_ellipse_2.png';

  static String img26195279Accoun = '$imagePath/img_26195279_accoun.png';

// onboarding fTwo images
  static String img28695003Market = '$imagePath/img_28695003_market.png';

  static String imgContrast = '$imagePath/img_contrast.svg';

  static String imgVector1Pink400 = '$imagePath/img_vector_1_pink_400.png';

  static String imgEllipse2155x78 = '$imagePath/img_ellipse_2_155x78.png';

  static String imgStar185x89 = '$imagePath/img_star_1_85x89.svg';

// onboarding fThree images
  static String imgContrastGray300 = '$imagePath/img_contrast_gray_300.svg';

  static String imgEllipse2157x153 = '$imagePath/img_ellipse_2_157x153.png';

  static String imgStar11 = '$imagePath/img_star_1_1.svg';

  static String imgVector1Cyan500 = '$imagePath/img_vector_1_cyan_500.svg';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgUserGray600 = '$imagePath/img_user_gray_600.svg';

  static String imgObjects = '$imagePath/img_objects.svg';

  static String imgImage1 = '$imagePath/img_image_1.png';

// last onboarding page images
  static String imgImage2 = '$imagePath/img_image_2.png';

// Common images
  static String imgArrowRight = '$imagePath/img_arrow_right.svg';

  static String imgArrowRightPrimary = '$imagePath/img_arrow_right_primary.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
