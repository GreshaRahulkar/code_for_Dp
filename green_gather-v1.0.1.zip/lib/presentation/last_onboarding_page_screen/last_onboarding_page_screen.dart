import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_subtitle.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_outlined_button.dart';

class LastOnboardingPageScreen extends StatelessWidget {
  const LastOnboardingPageScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 20.v,
          ),
          child: Column(
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgImage2,
                height: 306.adaptSize,
                width: 306.adaptSize,
              ),
              SizedBox(height: 18.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 200.h,
                  margin: EdgeInsets.only(left: 12.h),
                  child: Text(
                    "Let’s create\na Better WORLD",
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.headlineLarge,
                  ),
                ),
              ),
              SizedBox(height: 12.v),
              CustomOutlinedButton(
                text: "Create an Account",
                buttonTextStyle: theme.textTheme.bodyLarge!,
              ),
              SizedBox(height: 16.v),
              CustomOutlinedButton(
                text: "Already have an account? Log In",
                buttonStyle: CustomButtonStyles.outlineBlackTL12,
                buttonTextStyle: theme.textTheme.bodyLarge!,
              ),
              SizedBox(height: 5.v),
              Text(
                "or",
                style: CustomTextStyles.bodySmallOpenSansPrimary,
              ),
              SizedBox(height: 5.v)
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      centerTitle: true,
      title: Column(
        children: [
          AppbarSubtitle(
            text: "Green",
            margin: EdgeInsets.only(right: 59.h),
          ),
          AppbarTitle(
            text: "Gather",
            margin: EdgeInsets.only(left: 50.h),
          )
        ],
      ),
    );
  }
}
